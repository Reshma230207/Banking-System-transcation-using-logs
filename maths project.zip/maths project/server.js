const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');
const session = require('express-session');
const path = require('path');

const app = express();
const port = 3000;

// --- DATABASE & SERVER CONFIGURATION ---
const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: 'Aspire@9', // IMPORTANT: Change this to your MySQL root password
    database: 'maths_portal'
};
const pool = mysql.createPool(dbConfig);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
    secret: 'a-powerful-and-secret-key-for-maths-portal',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false, httpOnly: true, maxAge: 24 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname)));

// --- AUTHENTICATION MIDDLEWARE ---
const requireAuth = (req, res, next) => {
    if (!req.session.userId) {
        return res.redirect('/login.html');
    }
    next();
};

// --- API ROUTES ---
app.post('/register', async (req, res) => {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
        return res.status(400).json({ success: false, message: 'All fields are required.' });
    }
    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const [result] = await pool.query('INSERT INTO users (name, email, password) VALUES (?, ?, ?)', [name, email, hashedPassword]);
        req.session.userId = result.insertId;
        res.json({ success: true, redirect: '/test.html' });
    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({ success: false, message: 'Email already exists.' });
        }
        res.status(500).json({ success: false, message: 'Server error.' });
    }
});

app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
        if (rows.length === 0) {
            return res.status(401).json({ success: false, message: 'Invalid credentials.' });
        }
        const user = rows[0];
        const isMatch = await bcrypt.compare(password, user.password);
        if (isMatch) {
            req.session.userId = user.id;
            res.json({ success: true, redirect: '/test.html' });
        } else {
            res.status(401).json({ success: false, message: 'Invalid credentials.' });
        }
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error.' });
    }
});

app.post('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) return res.status(500).json({ success: false });
        res.json({ success: true, redirect: '/login.html' });
    });
});

app.get('/api/user-data', requireAuth, async (req, res) => {
    try {
        const [userRows] = await pool.query('SELECT id, name, email FROM users WHERE id = ?', [req.session.userId]);
        const [resultsRows] = await pool.query('SELECT score, time_taken, test_date FROM test_results WHERE user_id = ? ORDER BY test_date DESC', [req.session.userId]);
        if (userRows.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found.' });
        }
        res.json({
            success: true,
            user: userRows[0],
            results: resultsRows
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error.' });
    }
});

app.post('/api/save-result', requireAuth, async (req, res) => {
    const { score, timeTaken } = req.body;
    try {
        await pool.query('INSERT INTO test_results (user_id, score, time_taken) VALUES (?, ?, ?)', [req.session.userId, score, timeTaken]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error.' });
    }
});

// --- PAGE SERVING ROUTES ---
app.get('/test.html', requireAuth, (req, res) => {
    res.sendFile(path.join(__dirname, 'test.html'));
});

// --- SERVER INITIALIZATION ---
(async () => {
    try {
        await pool.query('SELECT 1');
        console.log('Connected to MySQL database.');
        app.listen(port, () => {
            console.log(`Server running on http://localhost:${port}`);
        });
    } catch (error) {
        console.error('Failed to connect to the database:', error);
        process.exit(1);
    }
})();